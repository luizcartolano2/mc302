package base.cartas;

/**
 * Created by LuizCartolan on 08/05/17.
 */
public enum HabilidadesLacaio {
    EXAUSTAO,PROVOCAR,INVESTIDA;
}
