package base;

/**
 * Created by LuizCartolan on 08/05/17.
 */
public enum TipoCarta {
    LACAIO, BUFF, DANO, DANO_AREA;
}
