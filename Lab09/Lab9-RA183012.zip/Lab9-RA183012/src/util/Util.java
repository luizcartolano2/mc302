package util;

public class Util {

    public final static int MAX_CARDS = 30;
    public final static int MAX_NOME = 5;
    public final static int MAO_INI = 3;
    public final static int MAX_TURNOS = 10;
    public final static int PODER_HEROI = 10;
    public final static int MANA_INI = 1;
    public final static int MAX_LACAIOS = 10;
    public final static int MAX_MANA = 2;
    public final static int MAX_ATAQUE = 6;
    public final static int MAX_VIDA = 6;

}
