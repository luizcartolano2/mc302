package base.cartas;

public enum HabilidadesLacaio {
	EXAUSTAO, PROVOCAR, INVESTIDA

}
