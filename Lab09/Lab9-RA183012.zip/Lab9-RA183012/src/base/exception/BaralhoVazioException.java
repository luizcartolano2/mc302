package base.exception;

/**
 * Created by duducartolano on 28/05/17.
 */
public class BaralhoVazioException extends IllegalArgumentException {

    public BaralhoVazioException(String message) {
        super(message);
    }

}
