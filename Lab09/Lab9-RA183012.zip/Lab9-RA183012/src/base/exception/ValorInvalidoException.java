package base.exception;

/**
 * Created by duducartolano on 28/05/17.
 */
public class ValorInvalidoException extends IllegalArgumentException{

    public ValorInvalidoException(String message) {
        super(message);
    }

}
