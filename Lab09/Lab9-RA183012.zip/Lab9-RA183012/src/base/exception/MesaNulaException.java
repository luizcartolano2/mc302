package base.exception;

/**
 * Created by duducartolano on 28/05/17.
 */
public class MesaNulaException extends Exception {

    public MesaNulaException(String message) {
        super(message);
    }
}
